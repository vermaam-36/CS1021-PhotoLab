package vermaa.msoe.lab09.sample;

import javafx.scene.paint.Color;
public interface Transformable{
    public Color apply(int y, Color color);
}
